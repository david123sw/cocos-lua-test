
--------------------------------
-- @module TransformObject
-- @extend BaseObject
-- @parent_module db

--------------------------------
--  @private 
-- @function [parent=#TransformObject] _setArmature 
-- @param self
-- @param #db.Armature value
-- @return TransformObject#TransformObject self (return value: db.TransformObject)
        
--------------------------------
--  @private 
-- @function [parent=#TransformObject] _setParent 
-- @param self
-- @param #db.Bone value
-- @return TransformObject#TransformObject self (return value: db.TransformObject)
        
--------------------------------
-- 
-- @function [parent=#TransformObject] getParent 
-- @param self
-- @return Bone#Bone ret (return value: db.Bone)
        
--------------------------------
-- 
-- @function [parent=#TransformObject] getArmature 
-- @param self
-- @return Armature#Armature ret (return value: db.Armature)
        
return nil
