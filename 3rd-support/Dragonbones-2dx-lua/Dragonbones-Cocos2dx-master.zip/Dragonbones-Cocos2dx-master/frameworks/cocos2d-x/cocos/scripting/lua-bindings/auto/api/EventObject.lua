
--------------------------------
-- @module EventObject
-- @extend BaseObject
-- @parent_module db

--------------------------------
-- 
-- @function [parent=#EventObject] getTypeIndex 
-- @param self
-- @return unsigned int#unsigned int ret (return value: unsigned int)
        
--------------------------------
-- 
-- @function [parent=#EventObject] getClassTypeIndex 
-- @param self
-- @return unsigned int#unsigned int ret (return value: unsigned int)
        
--------------------------------
-- 
-- @function [parent=#EventObject] EventObject 
-- @param self
-- @return EventObject#EventObject self (return value: db.EventObject)
        
return nil
