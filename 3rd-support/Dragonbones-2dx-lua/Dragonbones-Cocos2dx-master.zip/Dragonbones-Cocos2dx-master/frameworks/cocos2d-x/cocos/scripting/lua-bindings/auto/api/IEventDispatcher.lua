
--------------------------------
-- @module IEventDispatcher
-- @parent_module db

--------------------------------
-- 
-- @function [parent=#IEventDispatcher] hasEvent 
-- @param self
-- @param #string type
-- @return bool#bool ret (return value: bool)
        
--------------------------------
--  @private 
-- @function [parent=#IEventDispatcher] _dispatchEvent 
-- @param self
-- @param #db.EventObject value
-- @return IEventDispatcher#IEventDispatcher self (return value: db.IEventDispatcher)
        
--------------------------------
--  @private 
-- @function [parent=#IEventDispatcher] _onClear 
-- @param self
-- @return IEventDispatcher#IEventDispatcher self (return value: db.IEventDispatcher)
        
return nil
