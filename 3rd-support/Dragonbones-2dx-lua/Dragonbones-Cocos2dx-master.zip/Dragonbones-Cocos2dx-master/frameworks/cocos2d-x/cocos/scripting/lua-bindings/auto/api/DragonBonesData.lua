
--------------------------------
-- @module DragonBonesData
-- @extend BaseObject
-- @parent_module db

--------------------------------
-- 
-- @function [parent=#DragonBonesData] getArmatureNames 
-- @param self
-- @return array_table#array_table ret (return value: array_table)
        
--------------------------------
--  @private 
-- @function [parent=#DragonBonesData] addArmature 
-- @param self
-- @param #db.ArmatureData value
-- @return DragonBonesData#DragonBonesData self (return value: db.DragonBonesData)
        
--------------------------------
-- 
-- @function [parent=#DragonBonesData] getArmature 
-- @param self
-- @param #string name
-- @return ArmatureData#ArmatureData ret (return value: db.ArmatureData)
        
--------------------------------
-- 
-- @function [parent=#DragonBonesData] getTypeIndex 
-- @param self
-- @return unsigned int#unsigned int ret (return value: unsigned int)
        
--------------------------------
-- 
-- @function [parent=#DragonBonesData] getClassTypeIndex 
-- @param self
-- @return unsigned int#unsigned int ret (return value: unsigned int)
        
--------------------------------
--  @private 
-- @function [parent=#DragonBonesData] DragonBonesData 
-- @param self
-- @return DragonBonesData#DragonBonesData self (return value: db.DragonBonesData)
        
return nil
