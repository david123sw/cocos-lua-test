
--------------------------------
-- @module WorldClock
-- @extend IAnimateble
-- @parent_module db

--------------------------------
-- 
-- @function [parent=#WorldClock] clear 
-- @param self
-- @return WorldClock#WorldClock self (return value: db.WorldClock)
        
--------------------------------
-- 
-- @function [parent=#WorldClock] contains 
-- @param self
-- @param #db.IAnimateble value
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#WorldClock] advanceTime 
-- @param self
-- @param #float passedTime
-- @return WorldClock#WorldClock self (return value: db.WorldClock)
        
--------------------------------
-- 
-- @function [parent=#WorldClock] remove 
-- @param self
-- @param #db.Armature armature
-- @return WorldClock#WorldClock self (return value: db.WorldClock)
        
--------------------------------
-- 
-- @function [parent=#WorldClock] add 
-- @param self
-- @param #db.Armature armature
-- @return WorldClock#WorldClock self (return value: db.WorldClock)
        
--------------------------------
-- 
-- @function [parent=#WorldClock] getInstance 
-- @param self
-- @return WorldClock#WorldClock ret (return value: db.WorldClock)
        
--------------------------------
-- 
-- @function [parent=#WorldClock] WorldClock 
-- @param self
-- @return WorldClock#WorldClock self (return value: db.WorldClock)
        
return nil
