
--------------------------------
-- @module TextureData
-- @extend BaseObject
-- @parent_module db

--------------------------------
-- 
-- @function [parent=#TextureData] generateRectangle 
-- @param self
-- @return Rectangle#Rectangle ret (return value: db.Rectangle)
        
return nil
