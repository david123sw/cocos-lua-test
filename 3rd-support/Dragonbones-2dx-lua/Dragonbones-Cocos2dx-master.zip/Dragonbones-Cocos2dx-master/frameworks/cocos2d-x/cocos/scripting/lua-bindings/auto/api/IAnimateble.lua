
--------------------------------
-- @module IAnimateble
-- @parent_module db

--------------------------------
-- 
-- @function [parent=#IAnimateble] advanceTime 
-- @param self
-- @param #float passedTime
-- @return IAnimateble#IAnimateble self (return value: db.IAnimateble)
        
return nil
