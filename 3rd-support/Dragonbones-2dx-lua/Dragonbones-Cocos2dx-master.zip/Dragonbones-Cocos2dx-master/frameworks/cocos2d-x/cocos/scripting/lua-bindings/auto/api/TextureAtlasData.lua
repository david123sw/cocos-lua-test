
--------------------------------
-- @module TextureAtlasData
-- @extend BaseObject
-- @parent_module db

--------------------------------
--  @private 
-- @function [parent=#TextureAtlasData] addTexture 
-- @param self
-- @param #db.TextureData value
-- @return TextureAtlasData#TextureAtlasData self (return value: db.TextureAtlasData)
        
--------------------------------
--  @private 
-- @function [parent=#TextureAtlasData] generateTexture 
-- @param self
-- @return TextureData#TextureData ret (return value: db.TextureData)
        
--------------------------------
--  @private 
-- @function [parent=#TextureAtlasData] getTexture 
-- @param self
-- @param #string name
-- @return TextureData#TextureData ret (return value: db.TextureData)
        
return nil
