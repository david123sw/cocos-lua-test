
--------------------------------
-- @module CCEventObject
-- @extend Ref
-- @parent_module db

--------------------------------
-- 
-- @function [parent=#CCEventObject] Slot 
-- @param self
-- @return Slot#Slot ret (return value: db.Slot)
        
--------------------------------
-- 
-- @function [parent=#CCEventObject] UserData 
-- @param self
-- @return void#void ret (return value: void)
        
--------------------------------
-- 
-- @function [parent=#CCEventObject] Name 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
-- 
-- @function [parent=#CCEventObject] Frame 
-- @param self
-- @return AnimationFrameData#AnimationFrameData ret (return value: db.AnimationFrameData)
        
--------------------------------
-- 
-- @function [parent=#CCEventObject] AnimationState 
-- @param self
-- @return AnimationState#AnimationState ret (return value: db.AnimationState)
        
--------------------------------
-- 
-- @function [parent=#CCEventObject] Armature 
-- @param self
-- @return Armature#Armature ret (return value: db.Armature)
        
--------------------------------
-- 
-- @function [parent=#CCEventObject] Type 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
-- 
-- @function [parent=#CCEventObject] Bone 
-- @param self
-- @return Bone#Bone ret (return value: db.Bone)
        
return nil
