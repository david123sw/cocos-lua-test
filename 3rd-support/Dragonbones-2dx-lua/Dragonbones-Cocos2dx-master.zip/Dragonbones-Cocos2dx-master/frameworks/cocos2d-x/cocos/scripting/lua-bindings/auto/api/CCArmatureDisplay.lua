
--------------------------------
-- @module CCArmatureDisplay
-- @extend Node,IArmatureDisplay
-- @parent_module db

--------------------------------
-- 
-- @function [parent=#CCArmatureDisplay] removeDragonEventType 
-- @param self
-- @param #string type
-- @return CCArmatureDisplay#CCArmatureDisplay self (return value: db.CCArmatureDisplay)
        
--------------------------------
-- 
-- @function [parent=#CCArmatureDisplay] advanceTimeBySelf 
-- @param self
-- @param #bool on
-- @return CCArmatureDisplay#CCArmatureDisplay self (return value: db.CCArmatureDisplay)
        
--------------------------------
--  @private 
-- @function [parent=#CCArmatureDisplay] dispose 
-- @param self
-- @return CCArmatureDisplay#CCArmatureDisplay self (return value: db.CCArmatureDisplay)
        
--------------------------------
-- 
-- @function [parent=#CCArmatureDisplay] getArmature 
-- @param self
-- @return Armature#Armature ret (return value: db.Armature)
        
--------------------------------
--  @private 
-- @function [parent=#CCArmatureDisplay] _onClear 
-- @param self
-- @return CCArmatureDisplay#CCArmatureDisplay self (return value: db.CCArmatureDisplay)
        
--------------------------------
--  @private 
-- @function [parent=#CCArmatureDisplay] _dispatchEvent 
-- @param self
-- @param #db.EventObject value
-- @return CCArmatureDisplay#CCArmatureDisplay self (return value: db.CCArmatureDisplay)
        
--------------------------------
-- 
-- @function [parent=#CCArmatureDisplay] addDragonEventType 
-- @param self
-- @param #string type
-- @return CCArmatureDisplay#CCArmatureDisplay self (return value: db.CCArmatureDisplay)
        
--------------------------------
-- 
-- @function [parent=#CCArmatureDisplay] hasEvent 
-- @param self
-- @param #string type
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#CCArmatureDisplay] getAnimation 
-- @param self
-- @return Animation#Animation ret (return value: db.Animation)
        
--------------------------------
--  @private 
-- @function [parent=#CCArmatureDisplay] create 
-- @param self
-- @return CCArmatureDisplay#CCArmatureDisplay ret (return value: db.CCArmatureDisplay)
        
--------------------------------
--  @private 
-- @function [parent=#CCArmatureDisplay] update 
-- @param self
-- @param #float passedTime
-- @return CCArmatureDisplay#CCArmatureDisplay self (return value: db.CCArmatureDisplay)
        
return nil
